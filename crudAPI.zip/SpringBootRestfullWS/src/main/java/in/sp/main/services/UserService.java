package in.sp.main.services;

import java.util.List;
import java.util.Optional;

import in.sp.main.entities.User;

public interface UserService {
	
	public User cretaeUser(User user);
	
	public List<User> getAllUsers();
	
	public Optional<User> getUserDetail(int id);
	
	public User updateUserDetail(int id,User newUser);
	
	public boolean DeleteUser(int id);
	 
}
