package in.sp.main.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import in.sp.main.entities.User;
import in.sp.main.services.UserService;

@RestController
public class MyController {

    @Autowired
    private UserService userservice;

    ////// POST: Add a new user
    @PostMapping("/user")
    public User addUserDetail(@RequestBody User user) {
        return userservice.cretaeUser(user);
    }
    

    ////// GET: Retrieve all users
    @GetMapping("/user")
    public List<User> getAllUserDetail() {
        return userservice.getAllUsers();/// give back to the
    }
    
    

    ////// GET: Retrieve a user by ID
//    @GetMapping("/user/{id}")
//    public ResponseEntity<User> getUserDetails(@PathVariable int id) {
//        User user = userservice.getUserDetail(id).orElse(null);
//        if (user != null) {
//            return ResponseEntity.ok().body(user);
//        } else {
//            return ResponseEntity.notFound().build();
//        }
//    }
    
    
   // here i change with more good way to presenting
    @GetMapping("/user/{id}")
    public ResponseEntity<Object> getUserDetails(@PathVariable int id) {
        User user = userservice.getUserDetail(id).orElse(null);
        
        if (user != null) {
            return ResponseEntity.ok().body(user);
        } else {
            // Returning a custom message with 404 status when user is not found
            return ResponseEntity
                    .status(HttpStatus.NOT_FOUND)
                    .body("User with ID " + id + " not found.");
        }
    }

 //////////////////////// PUT: Update a user by ID//////////////////////////////////////
    @PutMapping("/user/{id}")
    public ResponseEntity<User> updateUserDetails(@PathVariable int id, @RequestBody User user) {
        User updateUser = userservice.updateUserDetail(id, user);

        if (updateUser != null) {
            return ResponseEntity.ok(updateUser);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

//    ////// DELETE: Delete a user by ID
//    @DeleteMapping("/user/{id}")
//    public ResponseEntity<Void> deleteUser(@PathVariable int id) {
//        userservice.DeleteUser(id);
//        return ResponseEntity.noContent().build();
//    }
    
    ///more good way
    @DeleteMapping("/user/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable int id) {
        boolean status = userservice.DeleteUser(id);  // Check if the user deletion is successful

        if (status) {
            // If user is deleted successfully, return a success message
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body("User deleted successfully.");
        } else {
            // If user deletion fails (user not found), return a failure message
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User with ID " + id + " not found.");
        }
    }

    
    
    
    
    
}
