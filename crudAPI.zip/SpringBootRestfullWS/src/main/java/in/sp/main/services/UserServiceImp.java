package in.sp.main.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import in.sp.main.entities.User;
import in.sp.main.repositories.UserRespository;

@Service
public class UserServiceImp implements UserService 

//here is save in data base
{
    @Autowired
    private UserRespository userRespository;

	@Override
	public User cretaeUser(User user) {
		
		
		return userRespository.save(user);
		}
	
	//here is get all data

	@Override
	public List<User> getAllUsers() {
		
		
		return userRespository.findAll();
	}

//here is get data by id

	@Override
	public Optional<User> getUserDetail(int id) {
	
		return userRespository.findById(id);
	}

//here is update data

	@Override
	public User updateUserDetail(int id, User newUser) {
		User userData = userRespository.findById(id).orElse(null);
		if (userData != null)
			
		{
			return userRespository.save(newUser);
		}
		else {
			
			
		throw new RuntimeException("user not found with id :"+id);
	}
			
	}

	//here is delete data


	@Override
	public boolean DeleteUser(int id) {
		
		if (userRespository.existsById(id))
				{
				userRespository.deleteById(id);
				
				return true;
		}
		else
		{
		return  false;
		}
	}
   
	
	
}
